//
//  test_module.js
//  sensor_webapp
//
//  Created by Yousung Cha on 9/4
//  Copyright © 2022 YH. All rights reserved.
//

const axios = require('axios').default
const instance = axios.create({
    timeout: 5000,
})

console.log("Test Module for sensor_webapp v1.0")
setInterval(insert_sensor_data, 300)

async function insert_sensor_data() {    
    let sensor_label_list = ['sensor_a', 'sensor_b', 'sensor_c', 'sensor_d', 'sensor_e', 'sensor_f']
    let sensor_data_list = []
    for (let label of sensor_label_list) {
        let Object = {
            sensor_id: label,
            top: (Math.random() * (50 - 5) + 5),
            middle: (Math.random() * (35 - 0) + 0),
            bottom: (Math.random() * (55 - 10) + 10),
            humidity: (Math.random() * (100 - 10) + 10)
        }
        sensor_data_list.push(Object)
    }
    let result = {
        create_time: Date.now(),
        frequency: 30,
        data_list: sensor_data_list
    }
    const response = await instance.post('http://127.0.0.1:8080/insert_sensor_data', result)
    process.stdout.write('.')
}