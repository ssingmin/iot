
// global ...
get_sensor_data($('#sensor_id').val())
let sensor_data = {}
let config = {
    type: 'line',
    options: { 
        animation: false
    }
}
let myChart = new Chart(document.getElementById('myChart'), config)
setInterval(function() {
    let sensor_id = $('#sensor_id').val()
    get_sensor_data(sensor_id)    
    get_sum_data(sensor_id)    
    let data_for_graph = drawing_graph(sensor_data)
    myChart.data.labels = data_for_graph.labels
    myChart.data.datasets = data_for_graph.datasets
    myChart.update()       
}, 1000)

// 알람 기능
let off_the_alarm = false
let btn_blink_flag = false
setInterval(() => {    
    let prefix_avg = parseFloat($('#avg').text())

    // 250을 넘을 경우
    if (prefix_avg >= 250.0) {

        // 알람 체크를 누르지 않은 경우
        if (off_the_alarm === false) {
            $('#btn_alarm').css('font-weight','bold')
            if (btn_blink_flag === true) {
                $('#btn_alarm').css('background-color','red')
                $('#btn_alarm').css('border','1px solid red')
                $('#ctn_chart').css('background-color','rgba(255,0,0,0.1)')
                btn_blink_flag = false
            } else {
                $('#btn_alarm').css('background-color','black')            
                $('#btn_alarm').css('border','1px solid black')
                $('#ctn_chart').css('background-color','#f5f5f5')
                btn_blink_flag = true
            }
        } else {
            $('#btn_alarm').removeAttr('style')    
            $('#ctn_chart').removeAttr('style')
            btn_blink_flag = false
        }
    } else {
        $('#btn_alarm').removeAttr('style')
        $('#ctn_chart').removeAttr('style')
        btn_blink_flag = false
    }
}, 500)
$('#btn_alarm').click(() => {
    off_the_alarm = true
})
$('#sensor_id').change(() => {
    off_the_alarm = false
})

$('#download_excel').click(() => {
    // check condition
    let date = new Date().toISOString().substring(0, 10)
    let start_date = { value: $('#start_date').val(), text: $('#start_date option:selected').text()}
    let end_date = { value: $('#end_date').val(), text: $('#end_date option:selected').text()}    
    if (start_date.value >= end_date.value) {
        console.log(start_date.value + " / " + end_date.value)
        //alert("시작 시간이 종료 시간보다 작아야 합니다.")
    }
    // build string
    let param = {
        sensor_id: $('#sensor_id').val(),
        start_date: date + ' ' + start_date.text + ':00',
        end_date: date + ' ' + end_date.text + ':00'
    }    
    $.ajax({
        type : "POST",            
        url : "/ajax_get_excel_data",
        data : param,
        success : function(res){
            window.open('/download_excel?file=' + res.file)
        },
        error : function(XMLHttpRequest, textStatus, errorThrown) {
            console.log("failed to connect server.")
            let error = { code: 400 }
            console.log(error)
        }
    })
})

// functions ...
function get_sensor_data(_sensor_id) {    
    let param = { sensor_id: _sensor_id }
    $.ajax({
        type : "POST",            
        url : "/ajax_get_sensor_data",
        data : param,
        success : function(res){
            try {
                sensor_data = res
                $('#temp_top').html(res[0].temp_top.toFixed(1))
                $('#temp_middle').html(res[0].temp_middle.toFixed(1))
                $('#temp_bottom').html(res[0].temp_bottom.toFixed(1))
                $('#humidity').html(res[0].humidity.toFixed(1))
            } catch(err) {
                $('#temp_top').html('')
                $('#temp_middle').html('')
                $('#temp_bottom').html('')
                $('#humidity').html('')
                console.log(err.message)
            }
        },
        error : function(XMLHttpRequest, textStatus, errorThrown) {
            console.log("failed to connect server.")
            let error = { code: 400 }
            console.log(error)
        }
    })
}
function get_sum_data(_sensor_id) {
    let param = { sensor_id: _sensor_id }
    $.ajax({
        type : "POST",            
        url : "/ajax_get_sensor_data_sum",
        data : param,
        success : function(res){
            try {
                $('#avg').html(res[0].avg.toFixed(1))
            } catch(err) {
                $('#avg').html('')
                console.log(err.message)
            }
        },
        error : function(XMLHttpRequest, textStatus, errorThrown) {
            console.log("failed to connect server.")
            let error = { code: 400 }
            console.log(error)
        }
    })
}

function drawing_graph(_sensor_data) {
    let sensor_data = _sensor_data
    let labels = [], temp_tops = [], temp_middles = [], temp_bottoms = [], humidities = [], cum_avgs = []

    // set serial data
    for (let data of sensor_data) {    
        labels.push(data.received_date.substring(11, 19))
        temp_tops.push(data.temp_top)
        temp_middles.push(data.temp_middle)
        temp_bottoms.push(data.temp_bottom)
        humidities.push(data.humidity)
        cum_avgs.push(data.cum_avg)
    }    
    let data_for_graph = {
        labels: labels.reverse(),
        datasets: [{
            label: 'Top',
            backgroundColor: 'rgb(255, 99, 132)',
            borderColor: 'rgb(255, 99, 132)',
            data: temp_tops.reverse()
        },{
            label: 'Middle',
            backgroundColor: 'rgb(200, 99, 132)',
            borderColor: 'rgb(200, 99, 132)',
            data: temp_middles.reverse()
        },{
            label: 'Bottom',
            backgroundColor: 'rgb(150, 99, 132)',
            borderColor: 'rgb(150, 99, 132)',
            data: temp_bottoms.reverse()
        },{
            label: 'Humidity',
            backgroundColor: 'rgb(99, 255, 132)',
            borderColor: 'rgb(99, 255, 132)',
            data: humidities.reverse()
        },{
            label: 'CumAvg',
            backgroundColor: 'rgb(100, 100, 100)',
            borderColor: 'rgb(100, 100, 100)',
            data: cum_avgs.reverse()
        }]
    }
    return data_for_graph
}