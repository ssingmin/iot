CREATE TABLE sensor_data(
    id INT(10) NOT NULL auto_increment,
    sensor_id VARCHAR(255) NOT NULL,
    temp_top FLOAT DEFAULT 0,
    temp_middle FLOAT DEFAULT 0,
    temp_bottom FLOAT DEFAULT 0,    
    humidity FLOAT DEFAULT 0,   
    cum_avg FLOAT DEFAULT 0,  
    received_date datetime default now(),
    primary key(id)
);
CREATE TABLE sensor_data_sum(
    sensor_id VARCHAR(255) NOT NULL,
    avg FLOAT DEFAULT 0,
    modified_date datetime default now(),
    primary key(sensor_id)
);
ALTER TABLE sensor_data CONVERT TO CHARACTER SET UTF8;
ALTER TABLE sensor_data_sum CONVERT TO CHARACTER SET UTF8;