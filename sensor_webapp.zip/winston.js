//
//  winston.js
//  sensor_webapp
//
//  Created by Yousung Cha on 9/4
//  Copyright © 2022 YH. All rights reserved.
//

const winston = require('winston');
const winstonDaily = require('winston-daily-rotate-file');
 
const logDir = 'logs'; 
const { combine, timestamp, printf, label } = winston.format;
 
const colorize = winston.format.colorize();
 
const logFormat = printf(({ level, message, label, timestamp }) => {
    return `${colorize.colorize(level, `[${timestamp}] [${level.toUpperCase()}] ${label ?? 'default'}:`)} ${message}`;
});
const getLogger = (path) => {
    const logger = winston.createLogger({
        format: combine(
            label({ label: path }), 
            timestamp({
                format: 'YYYY-MM-DD HH:mm:ss',
            }),
            logFormat,
        ),
        transports: [
            
            new winstonDaily({
                level: 'info',
                datePattern: 'YYYY-MM-DD',
                dirname: logDir,
                filename: `%DATE%.log`,
                maxFiles: 30,  
                zippedArchive: true,
            }),
            
            new winstonDaily({
                level: 'error',
                datePattern: 'YYYY-MM-DD',
                dirname: logDir + '/error',  
                filename: `%DATE%.error.log`,
                maxFiles: 30,
                zippedArchive: true,
            }),
        ],
    });
 
    const httpLogger = winston.createLogger({
        format: combine(
            label({ label: 'http' }),
            timestamp({
                format: 'YYYY-MM-DD HH:mm:ss',
            }),
            logFormat,
        ),
        transports: [
            new winstonDaily({
                level: 'info',
                datePattern: 'YYYY-MM-DD',
                dirname: logDir,
                filename: `%DATE%.http.log`,
                maxFiles: 30, 
                zippedArchive: true,
            })
        ],
    });
 
    logger.stream = {
        write: (message, encoding) => {
            httpLogger.info(message);
        }
    };
 
    if (process.env.NODE_ENV !== 'production') {
        logger.add(new winston.transports.Console({                   
            format: combine(
                label({ label: path }),
                timestamp(),
                logFormat,                                
            )
        }));
    }
 
    return logger;
};
 
module.exports = getLogger;
