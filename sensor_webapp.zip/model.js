//
//  model.js
//  sesnor_webapp
//
//  Created by Yousung Cha on 9/4
//  Copyright © 2022 YH. All rights reserved.
//

require('dotenv').config({ path: './resources/application_pc_' + process.env.profile + '.env'})

// logger
const logger = require('./winston')('model.js')

// custom 
const consts = require('./consts')

// databases
const knex = require('knex')({
    client: 'mysql2',         
    connection: consts.db_properties
}) 

// Setting 1 : DB
exports.insert_sensor_data = async function(_sensor) {
    let result = knex('sensor_data').insert({
        sensor_id: _sensor.sensor_id,
        temp_top: _sensor.top,
        temp_middle: _sensor.middle,
        temp_bottom: _sensor.bottom,
        humidity: _sensor.humidity,
        cum_avg: _sensor.cum_avg
    })
    return result
}
exports.insert_sensor_data_sum = async function(_sum) {
    let result = knex('sensor_data_sum').insert({
        sensor_id: _sum.sensor_id,
        avg: _sum.avg
    }).onConflict('id').merge()
    return result
}
exports.select_sensor_data = async function(_sensor_id) {
    let result = knex.select('*')
                    .from('sensor_data')
                    .where('sensor_id', _sensor_id)
                    .orderBy('received_date', 'desc')
                    .limit(60)
    return result
}
exports.select_sensor_data_by_period = async function(_sensor_id) {
    let result = knex.select('*')
                    .from('sensor_data')
                    .where('sensor_id', _sensor_id)
                    //.where('received_date', '>=', _start_date)
                    //.where('received_date', '<=', _end_date)
    return result
}
exports.select_sensor_data_sum = async function(_sensor_id) {
    let result = knex.select('*')
                    .from('sensor_data_sum')
                    .where('sensor_id', _sensor_id)
    return result
}
