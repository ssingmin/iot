//
//  consts.js
//  sensor_webapp
//
//  Created by Yousung Cha on 9/4
//  Copyright © 2022 YH. All rights reserved.
//

module.exports = Object.freeze({
    db_properties : {
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        pool: {            
            min: 0,
            max: 10
        }
    }
})