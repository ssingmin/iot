//
//  controller.js
//  sensor_webapp
//
//  Created by Yousung Cha on 9/4
//  Copyright © 2022 YH. All rights reserved.
//

require('dotenv').config({ path: './resources/application_pc_' + process.env.profile + '.env'})

// #preprocess. logger
const logger = require('./winston')('controller.js')
const path = require('path')
const mime = require('mime')
const fs = require('fs')

// #preprocess. express session modules
const express = require('express')
const controller_router = express.Router()

// #preprocess. custom
const excel = require('exceljs')
const model = require('./model')
const EXCEL_PATH = './excels/'

// 1. view
controller_router.get('/', (req, res) => {
    // 폴더가 없으면 생성
    if (!fs.existsSync(EXCEL_PATH)) {
        fs.mkdirSync(EXCEL_PATH)
    }
    res.render('main')
})

// 2. controller for remote call
//   - Rest API is named from the caller's point of view.
controller_router.post('/insert_sensor_data', async (req, res) => {

    // 싱글 데이터를 멀티로 받을 수 있도록 수정 필요 >> data_list[0] 
    let response = { code: 400 }
    try {
        let data_list = req.body.data_list        
        let frequency = req.body.frequency

        // processing ...        
        for (let data of data_list) {            
            let prev_cum = await model.select_sensor_data_sum(data.sensor_id)
            prev_cum = (prev_cum.length === 0) ? [ { avg: 0.0} ] : prev_cum
            let current_cum = prev_cum[0].avg + ((data.top + data.middle + data.bottom) / 3.0) * (frequency / 3600.0)            
            let param = {
                sensor_id: data.sensor_id,
                avg: current_cum
            }
            data.cum_avg = current_cum
            await model.insert_sensor_data_sum(param)
            await model.insert_sensor_data(data)
        }
        response.code = 200
    } catch(err) {        
        report_error(err, '/insert_sensor_data')        
    }    
    logger.info('Response[/insert_sensor_data] : ' + JSON.stringify(response))
    res.send(response)
})
controller_router.get('/download_excel', function(req, res) {
    try {
        let file_path = EXCEL_PATH + req.query.file

        // send compressed files
        res.setHeader('Content-disposition', 'attachment; filename=' + req.query.file)
        res.setHeader('Content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        
        let file = file_path        
        let file_stream = fs.createReadStream(file)
        file_stream.pipe(res)

        // download status
        file_stream.on('error', () => { }) 
        file_stream.on('data', (chunk) => { })
        file_stream.on('end', () => { })
        file_stream.on('close', () => {            
            logger.info(file_path + ' has been downloaded.')
            fs.unlink(file_path, (err) => {
                logger.info(file_path + ' has been removed.')
            })
        })
    } catch (exception) {
        logger.error(exception.message)
    }
})

// 3. controller for AJAX
controller_router.post('/ajax_get_sensor_data', async (req, res) => {
    let response = { code: 400 }
    try {
        let query_result = await model.select_sensor_data(req.body.sensor_id)
        response = query_result
        response.code = 200
    } catch(err) {
        report_error(err, '/ajax_get_sensor_data')        
    }    
    //console.log('Response[/ajax_get_sensor_data] : length(' + response.length + ')')
    res.send(response)
})
controller_router.post('/ajax_get_sensor_data_sum', async (req, res) => {
    let response = { code: 400 }
    try {
        let query_result = await model.select_sensor_data_sum(req.body.sensor_id)
        response = query_result        
        response.code = 200                
    } catch(err) {
        report_error(err, '/ajax_get_sensor_data_sum')
    }
    //console.log('Response[/ajax_get_sensor_data_sum]')
    //console.log(JSON.stringify(response))
    res.send(response)
})
controller_router.post('/ajax_get_excel_data', async (req, res) => {    
    let response = { code: 400 }    
    try {

        // To do ...
        let result = await model.select_sensor_data_by_period(req.body.sensor_id, req.body.start_date, req.body.end_date)

        // excel
        const workbook = new excel.Workbook()
        const worksheet = await workbook.addWorksheet(req.body.sensor_id)        
        worksheet.columns = [
            { header: 'id', key: 'id', width: 10 },
            { header: 'top', key: 'temp_top', width: 10 },
            { header: 'middle', key: 'temp_middle', width: 10 },
            { header: 'bottom', key: 'temp_bottom', width: 10 },
            { header: 'humidity', key: 'humidity', width: 10 },
            { header: 'received_date', key: 'received_date', width: 32 }
        ];
        await worksheet.insertRows(2, result)        
        await workbook.xlsx.writeFile(EXCEL_PATH + req.body.sensor_id + '.xlsx')
        console.log(result)
        response.file = req.body.sensor_id + '.xlsx'
        response.code = 200
    } catch(err) {
        report_error(err, '/ajax_get_excel_data')
    }
    res.send(response)
})

// 4. exports module and etc 
module.exports = controller_router;
function report_error(_err, _function_name) {
    logger.error('(' + path.basename(__filename) + ', ' +  _function_name + ') : ' + _err.message)
}
