//
//  index.js
//  sensor_webapp
//
//  Created by Yousung Cha on 9/4
//  Copyright © 2022 YH. All rights reserved.
//

require('dotenv').config({ path: './resources/application_pc_' + process.env.profile + '.env'})

// #preprocess. express session modules
const express = require('express')
const app = express()

// #preprocess. utilities
const body_parser = require('body-parser')

// #preprocess. logger
const logger = require('./winston')('index.js')

// #preprocess. custom
const controller = require('./controller.js')

// 1. application setting
app.set('view engine','ejs');
app.use(body_parser.urlencoded({extended: false}))
app.use(body_parser.json())
app.use(express.static(__dirname + '/public'));

// 2. router setting
app.use('/', controller)

// 3. start web server
app.listen(process.env.WEB_SERVER_PORT, (err) => {    
    logger.info("Server has been started on port : " + process.env.WEB_SERVER_PORT)
})